<!-- Badges: Ersetze <OWNER>/<REPO> durch deinen Namespace -->
[![CI](https://github.com/<OWNER>/<REPO>/actions/workflows/ci.yml/badge.svg)](https://github.com/<OWNER>/<REPO>/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/<OWNER>/<REPO>?display_name=tag)](https://github.com/<OWNER>/<REPO>/releases)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)

> **Hinweis:** Der Release-Workflow erzeugt beim Push eines Tags `vX.Y` automatisch ein Release mit Namen **„PixelBeav Version X.Y“** und hängt ein ZIP an.
