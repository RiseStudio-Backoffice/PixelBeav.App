## v1.1.0 — 2025-10-15
- Versionsnummer erhöht. Keine Code-Änderungen.

