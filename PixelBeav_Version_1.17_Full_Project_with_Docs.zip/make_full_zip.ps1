# make_full_zip.ps1 — ZIP mit echter Ordnerstruktur (ohne extra Top-Level-Ordner)
$ErrorActionPreference = 'Stop'

# Ausgabename
$zipName = "PixelBeav_Version_1.17_Full_Project_with_Docs.zip"

# Repo-Root = aktuelles Verzeichnis
$root = (Get-Location).Path

# 1) docs/ + Handbuch sicherstellen
$docsDir  = Join-Path $root 'docs'
$handbuch = Join-Path $docsDir 'HANDBUCH_PixelBeav.md'
if (-not (Test-Path $docsDir)) { New-Item -ItemType Directory -Path $docsDir | Out-Null }
if (-not (Test-Path $handbuch)) {
@"
# Handbuch – PixelBeav (Stand: $(Get-Date -Format 'yyyy-MM-dd'))

Dieses Handbuch fasst die Ergebnisse der heutigen Session zusammen und beschreibt, wie du dir **jederzeit die neuesten Codedaten aus dem öffentlichen Repo** holst.
(…)
"@ | Set-Content -Path $handbuch -Encoding UTF8
}

# 2) Staging-Ordner im Temp anlegen (hierhin wird die Struktur 1:1 kopiert)
$staging = Join-Path $env:TEMP "pixelbeav_zip_staging"
if (Test-Path $staging) { Remove-Item $staging -Recurse -Force }
New-Item $staging -ItemType Directory | Out-Null

# 3) Dateien (ohne .git/.vs/bin/obj/publish) strukturerhaltend ins Staging kopieren
$excludeSegments = @('.git', '.vs', 'bin', 'obj', 'publish')

Get-ChildItem -Recurse -File | ForEach-Object {
    $fp = $_.FullName
    $exclude = $false
    foreach ($seg in $excludeSegments) {
        if ($fp -like "*\${seg}\*") { $exclude = $true; break }
    }
    if (-not $exclude) {
        $rel  = $fp.Substring($root.Length + 1)         # Pfad relativ zum Repo-Root
        $dest = Join-Path $staging $rel
        New-Item -ItemType Directory -Path (Split-Path $dest) -Force | Out-Null
        Copy-Item $fp $dest -Force
    }
}

# 4) ZIP aus dem Staging erzeugen (Ordnerstruktur bleibt erhalten)
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zipFull = Join-Path $root $zipName
if (Test-Path $zipFull) { Remove-Item $zipFull -Force }
[IO.Compression.ZipFile]::CreateFromDirectory($staging, $zipFull)

# 5) Aufräumen
Remove-Item $staging -Recurse -Force

Write-Host "Fertig: $zipName" -ForegroundColor Green
