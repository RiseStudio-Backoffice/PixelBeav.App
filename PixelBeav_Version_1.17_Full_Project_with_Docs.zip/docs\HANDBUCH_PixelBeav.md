﻿# Handbuch â€“ PixelBeav (Stand: 2025-10-15)

Dieses Handbuch fasst die Ergebnisse der heutigen Session zusammen und beschreibt, wie du dir **jederzeit die neuesten Codedaten aus dem Ã¶ffentlichen Repo** holst.

## 1) Projekt-Ãœberblick
- **Technik:** .NET 9 + WPF (Windows), WinForms nur fÃ¼r FolderBrowserDialog.
- **Release-Namen:** â€ž**PixelBeav Version {X.Y}**â€œ (aktueller Chat-Stand: **1.16**).
- **Layout (links):** genau **2 Spalten**, feste Breite (fÃ¼r **320Ã—150**-Kacheln), **kein** automatisches Mitwachsen.
- **Thumbnails:** **320Ã—150 px**, **abgerundete Ecken** (CornerRadius=10). Bild als **Background derselben Border** (ImageBrush, Stretch="Fill") â†’ **kein Zuschneiden**, bewusst â€žzusammengeschobenâ€œ.
- **SchlieÃŸen-Button:** **20Ã—20 px**, oben rechts, **3 px** Abstand (Margin  ,3,3,0), Icon Assets/close.png.
- **Details (rechts):** Klick auf Kachel setzt SelectedGame â†’ Cover/Titel/Beschreibung.
- **Blacklist:** Sofort-LÃ¶schen; Anzeige Ã¼ber â€žBlacklist anzeigenâ€œ.

## 2) Neueste Codedaten holen (Repo)
Repo: https://github.com/RiseStudio-Backoffice/PixelBeav.App

### Visual Studio
1. Git â†’ Repository-Einstellungen: origin = https://github.com/RiseStudio-Backoffice/PixelBeav.App.git
2. Git â†’ Pull (Branch master)
3. Startprojekt PixelBeav.App â†’ F5

### CLI
git clone https://github.com/RiseStudio-Backoffice/PixelBeav.App.git
cd PixelBeav.App
git pull origin master
dotnet restore PixelBeavLibrary.sln
dotnet build PixelBeavLibrary.sln -c Release

## 3) CI & Branch-Schutz (Kurz)
- Workflow: .github/workflows/ci.yml
- Required Checks nutzen **Job-Namen** (z. B. CI / build), nicht nur â€žCIâ€œ.
- Badge:
[![CI](https://github.com/RiseStudio-Backoffice/PixelBeav.App/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/RiseStudio-Backoffice/PixelBeav.App/actions/workflows/ci.yml)
