# Changelog

Dieses Projekt folgt sinngemäß „Keep a Changelog“. Versionen heißen **„PixelBeav Version X.Y“**.

## [Unreleased]

## [1.17] - 2025-10-15
### Added
- `docs/`-Ordner eingeführt.
- Handbuch `docs/HANDBUCH_PixelBeav.md` ergänzt.
- `CHANGELOG.md` nach `docs/CHANGELOG.md` migriert.
- Hinweise zu CI/Branch‑Regeln in die Doku aufgenommen.
