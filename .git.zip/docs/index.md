# PixelBeav – Dokumentation

- **Handbuch (Stand: 2025-10-15)**: [HANDBUCH_PixelBeav.md](./HANDBUCH_PixelBeav.md)
- **Changelog:** [CHANGELOG.md](./CHANGELOG.md)

Weitere Themen (optional):
- Build/CI-Setup (ci.md)
- How-To Build & Start (howto-build.md)
