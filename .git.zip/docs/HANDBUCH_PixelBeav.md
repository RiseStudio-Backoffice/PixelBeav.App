# Handbuch – PixelBeav (Stand: 2025-10-15)

Dieses Handbuch fasst die Ergebnisse der heutigen Session zusammen und beschreibt, wie du dir **jederzeit die neuesten Codedaten aus dem öffentlichen Repo** holst.

---

## 1) Projekt-Überblick

- **Technik:** .NET 9 + WPF (Windows), WinForms nur für `FolderBrowserDialog`.
- **Release-Namen:** „**PixelBeav Version {X.Y}**“ (aktueller Chat-Stand: **1.16**).
- **Layout (links):** genau **2 Spalten**, feste Breite (für **320×150**-Kacheln), **kein** automatisches Mitwachsen.
- **Thumbnails:** **320×150 px**, **abgerundete Ecken** (CornerRadius=10). Das Bild wird **als Background derselben Border** mit `ImageBrush` und `Stretch="Fill"` gerendert → **kein Zuschneiden**, bewusst „zusammengeschoben“.
- **Schließen-Button:** **20×20 px**, oben rechts, **3 px** Abstand (Margin `0,3,3,0`), Icon `Assets/close.png`.
- **Details (rechts):** Klick auf Kachel setzt `SelectedGame` → Cover/Titel/Beschreibung.
- **Blacklist:** Sofort-Löschen (Eintrag verschwindet direkt), Eintrag wird **persistiert** und kann über **„Blacklist anzeigen“** eingesehen werden.

---

## 2) Neueste Codedaten holen (Repo)

**Repo (öffentlich):** https://github.com/RiseStudio-Backoffice/PixelBeav.App

### Visual Studio (ohne Terminal)
1. **Git → Repository-Einstellungen**: Prüfen, dass `origin` auf  
   `https://github.com/RiseStudio-Backoffice/PixelBeav.App.git` zeigt.
2. **Git → Pull** (Branch `master`) holt den neuesten Stand.
3. **Build/Start:** Startprojekt `PixelBeav.App` wählen → **F5**.

### Alternativ per CLI
```bash
git clone https://github.com/RiseStudio-Backoffice/PixelBeav.App.git
cd PixelBeav.App
git pull origin master
dotnet restore PixelBeavLibrary.sln
dotnet build PixelBeavLibrary.sln -c Release
```

---

## 3) CI & Branch-Schutz (Kurzüberblick)

- **CI-Workflow:** `.github/workflows/ci.yml`  
  - Trigger: `push`/`pull_request` auf `main, master`, optional `workflow_dispatch`.
  - In Branch-Regeln wird der **Job-Name** (z. B. `CI / build`) hinterlegt – **nicht** nur „CI“.
- **CI-Status ansehen:**
  1) **Actions-Tab** → Workflow „CI“ → letzter Run auf `master`.
  2) **Commit-Seite** → Abschnitt **Checks**.
  3) **README-Badge** (dauerhaft):
     ```md
     [![CI](https://github.com/RiseStudio-Backoffice/PixelBeav.App/actions/workflows/ci.yml/badge.svg?branch=master)](https://github.com/RiseStudio-Backoffice/PixelBeav.App/actions/workflows/ci.yml)
     ```
- **Branch Protection (Empfehlung):**
  - **Prevent deletions**, **Force-Push verbieten**.
  - Optional: **Require a pull request before merging** + **Require status checks to pass** → `CI / build` (oder Gate-Job wie `CI / required`).

---

## 4) Troubleshooting (heute besprochene Punkte)

- **Rechte Rundungen fehlen:** Meist Viewport-Clipping. Links Breite/Padding konsistent halten; Bild **als Background exakt der Border** mit CornerRadius (nicht als Kind-`<Image>`).
- **Bilder wirken „abgeschnitten“:** Prüfen, dass **`ImageBrush.Stretch="Fill"`** aktiv ist (kein `UniformToFill`). Kein Zuschneiden, sondern *einpassen/zusammenschieben*.
- **Close-Button unsichtbar:** Resource-Pfad (`Assets/close.png`, Build Action=Resource), **ZIndex** > Select-Button, **Margin `0,3,3,0`**, Größe **20×20**.
- **Required Checks in Branch-Regeln fehlen:** GitHub erwartet **Job-Namen** (z. B. `CI / build`). Ein Lauf muss auf **`master`** vorhanden sein. Namen notfalls **manuell eintippen** und mit Enter bestätigen.

---

## 5) Nächste sinnvolle Schritte

- **README**: Badges (CI/Release/License) einfügen.
- **Rules/Classic Branch Protection** finalisieren (Required Checks hinterlegen).
- **Optionale Features**:
  - Letterboxing-Modus (ohne Verzerrung, mit Balken),
  - Blacklist-Fenster (Suchen, Re-Enable),
  - Hover/Pressed-Stil für den Close-Button.

---

### Hinweis zu Code-ZIPs
Künftige **Code-ZIPs** liefere ich **ohne Unterordner (flat)**, damit du sie direkt in **`pixelbeav.app/`** kopieren kannst.

## Regel: Mini-Codeänderungen (< 3 Zeilen)

Wenn eine Code-Änderung **weniger als drei (3) Zeilen** umfasst, gilt Folgendes:

- **Kein ZIP.** Die Änderung wird **direkt im Chat** ausgegeben.
- **Exakte Angabe von Datei & Zeilen:** Für jede Änderung wird **Dateipfad** und **genaue Zeilennummern** angegeben (z. B. `Views/MainWindow.xaml.cs`, Zeilen 42–43).
- **Nur die geänderten Zeilen** ausgeben (vorher/nachher), **keine** vollständige Datei.
- Bei mehreren Mini-Änderungen in unterschiedlichen Dateien: **jede Änderung** separat mit Pfad und Zeilenbereich aufführen.
- Überschreitet die Änderung **≥ 3 Zeilen** (inkl. Einfügen/Ersetzen/Entfernen), wird wieder **per ZIP** mit Original-Relativpfaden geliefert.

## Hinweise zu code-zips

### Speicherort des Handbuchs (verbindlich)
Die Handbuchdatei **HANDBUCH_PixelBeav.md** liegt im Projekt unter **`pixelbeav.app/Docs/`**.

### Einzeldatei-Änderungen als ZIP (Ordnerstruktur)

Wenn **Einzeldateien** separat als ZIP geliefert werden, muss das ZIP **immer** die **originale Ordnerstruktur mit dem originalen Relativpfad** enthalten.

- Beispiel: Wird `Views/MainWindow.xaml.cs` geändert und als ZIP geliefert, enthält das ZIP den Pfad **`PixelBeav.App/Views/MainWindow.xaml.cs`** (bzw. den projektrealen Root-Relativpfad).
- Keine „flachen“ ZIPs bei Einzelfiles – die Pfadstruktur muss erhalten bleiben, damit ich die Datei direkt in meinen Projektbaum kopieren kann.
- Dieses Verhalten gilt **ab sofort** für alle Einzeldatei-ZIPs zusätzlich zum Namensschema **„PixelBeav App Version {MAJOR.MINOR}.zip“**.

### Namensschema für ausgelieferte ZIPs (verbindlich)

Alle ZIP-Dateien, die du mir auslieferst, **müssen** exakt folgendes Format haben:

**PixelBeav App Version {MAJOR.MINOR}.zip**

- Die Versionsnummer wird bei jeder neuen Lieferung **fortlaufend** erhöht (MINOR +1).
- Beispiel: `PixelBeav.App Version-1.17.zip`, danach `PixelBeav.App Version-1.18.zip`, usw.
- Inhalt: wie gehabt mit Original-Relativpfaden (z. B. `Views/...`).
- Keine Zusätze oder Suffixe im Dateinamen.

### Namensschema für Einzeldatei-Downloads (verbindlich)
Wenn **genau eine Datei** als ZIP ausgeliefert wird, heißt die ZIP **exakt wie die Datei**, nur mit `.zip`-Endung.
- Beispiel: Datei `HANDBUCH_PixelBeav.md` → ZIP-Name **`handbuch.zip`**.
- Das ZIP enthält die **originale Ordnerstruktur**, hier also: `Docs/HANDBUCH_PixelBeav.md`.


### Meldungen

Dieser Abschnitt definiert das standardisierte Format für System‑, Hinweis‑ und Fehlermeldungen innerhalb des PixelBeav‑Projekts. Ziel ist es, alle Meldungen klar erkennbar, konsistent und handlungsorientiert darzustellen.

#### Symbol‑Klassifizierung

| Symbol | Typ | Zweck |
|--------|------|-------|
| ✅ | **Erfolg** | Bestätigung, dass eine Aktion erfolgreich abgeschlossen wurde |
| ⚙️ | **Info** | Hinweis auf interne Aktionen (z. B. Projekt‑Scan, Datei eingelesen) |
| ⚠️ | **Warnung** | Abweichung oder Rückfrage, aber kein Fehler |
| 🚨 | **Fehler / Blocker** | Fehlende Dateien, Kompilierfehler, kritische Konflikte |

#### Standard‑Blockaufbau

Jede Meldung wird in einem einheitlichen Block ausgegeben:

```
[SYMBOL] [TITEL IN VERSALIEN]
Typ: <Info | Warnung | Fehler | Erfolg>
Pfad/Kontext: <root-relativer Pfad oder Kurzkontext>
Beschreibung: <Was ist passiert?>
Aktion: <empfohlene Folgeaktion oder klare Frage>
```

Beispiel (Warnung):

```
⚠️ DOWNLOAD NICHT MÖGLICH
Typ: Warnung
Kontext: Datei konnte nicht bezogen werden (Zugriff verweigert oder Quelle ungültig)
Beschreibung: Der angegebene Download-Link ist nicht verfügbar oder erfordert Authentifizierung.
Aktion: Bitte lade die betroffenen Dateien als ZIP mit korrektem Root-Pfad hoch (z. B. `docs/…`, `views/…`).
```

#### Häufige Standardfälle

1. **Download nicht möglich**
   Bedingungen (eine oder mehrere):
   - Link extern, abgelaufen oder privat  
   - Download im Chat nicht erlaubt (fehlende Web-Berechtigung)  
   - Anhang fehlt oder ist leer

   **Meldung:**
   ```
   ⚠️ DOWNLOAD NICHT MÖGLICH
   Typ: Warnung
   Kontext: Externe Quelle oder fehlender Anhang
   Beschreibung: Die Datei kann im Chat nicht heruntergeladen werden.
   Aktion: Bitte lade die Dateien als ZIP hoch, mit Original-Ordnerstruktur ab Root (z. B. `docs/…`, `views/…`).
   ```

2. **Datei fehlt (im aktuellen Chat nicht vorhanden)**
   ```
   🚨 DATEI FEHLT!
   Typ: Fehler
   Pfad/Kontext: <z. B. views/MainWindow.xaml>
   Beschreibung: Die Datei ist für die Änderung erforderlich, wurde aber nicht bereitgestellt.
   Aktion: Soll ich die Datei anlegen? (ja/nein)
   ```

3. **Konflikt erkannt**
   ```
   ⚠️ KONFLIKT ERKANNT!
   Typ: Warnung
   Datei: <Pfad>
   Beschreibung: Lokale Version unterscheidet sich vom zuletzt generierten Stand.
   Aktion: Überschreiben / Mergen / Abbrechen? (überschreiben/mergen/abbrechen)
   ```

4. **Erfolg / Abschluss**
   ```
   ✅ FERTIG
   Typ: Erfolg
   Kontext: <z. B. Mini-Änderung angewendet>
   Beschreibung: Änderung umgesetzt; Build-/Lint-Check lokal konsistent (soweit möglich).
   Aktion: —
   ```

#### Prozess‑ und Darstellungsregeln

- **Sichtbarkeit zuerst:** Bei Blockern (🚨) oder Unklarheiten (⚠️) immer zuerst den Block anzeigen, dann um Entscheidung bitten.  
- **Root‑Konvention im ZIP:** ZIP‑Inhalte beginnen immer an der Projekt‑Root des Pfads (`docs/`, `views/`, `assets/` …), ohne übergeordnete Ordner.  
- **Versionierte Mehrdateien‑ZIPs:** `pixelbeav.app Version-{MAJOR.MINOR+1}.zip` — MINOR pro Lieferung + 1; bei .10 → MAJOR + 1, MINOR = 0.  
- **Mini‑Änderungen (< 3 Zeilen):** Keine ZIPs; exakte *Datei + Zeilenangaben* und *Vorher → Nachher‑Snippet*.  
- **Antwortverhalten:** Auf Meldungen kann mit „ja“, „nein“, „weiter“ oder spezifischen Optionen geantwortet werden; Folgeaktionen erfolgen kontextabhängig.

#### Meldungscodes (optional)

| Code | Bedeutung | Beispiel |
|------|------------|----------|
| `MSG-DOWNLOAD-BLOCKED` | Download fehlgeschlagen | ⚠️ DOWNLOAD NICHT MÖGLICH |
| `MSG-MISSING-FILE` | Fehlende Datei erkannt | 🚨 DATEI FEHLT! |
| `MSG-CONFLICT` | Versionskonflikt | ⚠️ KONFLIKT ERKANNT! |
| `MSG-BUILD-FAIL` | Kompilation gescheitert | 🚨 BUILD-FEHLER |
| `MSG-COMPLETE` | Vorgang erfolgreich abgeschlossen | ✅ FERTIG |

#### Technischer Hinweis

Sollte der Chat später in einer Oberfläche mit Farb‑ oder Markdown‑Unterstützung dargestellt werden, können die Symbole automatisch als farbige Labels (rot/gelb/grün/blau) gerendert werden. Der hier definierte Blockstil bleibt davon unberührt.
