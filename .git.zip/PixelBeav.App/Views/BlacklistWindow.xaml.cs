using System.Windows;

namespace PixelBeav.App.Views
{
    public partial class BlacklistWindow : Window
    {
        public BlacklistWindow()
        {
            InitializeComponent();
        }
    }
}
